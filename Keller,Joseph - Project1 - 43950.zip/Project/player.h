/* 
 * File:   player.h
 * Author: Joseph Keller
 * Project 1 - CIS 17A - Connect Four
 * Created on May 4, 2015, 2:19 PM
 */

#ifndef PLAYER_H
#define	PLAYER_H

struct Stats{
    int wins;
    int losses;
    int draws;
};

#endif	/* PLAYER_H */

